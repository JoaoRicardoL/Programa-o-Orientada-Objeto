package br.com.unipar.poo;

public enum Classe {
    MAGO,
    GUERREIRO,
    ARQUEIRO
}