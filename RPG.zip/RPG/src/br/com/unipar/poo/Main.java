package br.com.unipar.poo;

import  java.util.Scanner;
import java.util.Random;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite seu nome do seu personagem:");
        String nome = sc.nextLine();

        System.out.println("Escolha sua classe");
        System.out.println("1 - MAGO");
        System.out.println("2 - GUERREIRO");
        System.out.println("3 - ARQUEIRO");
        int escolhaClasse = sc.nextInt();

        Classe classeEscolhida;
        switch (escolhaClasse) {
            case 1:
                classeEscolhida = Classe.MAGO;
                break;
                case 2:
                    classeEscolhida = Classe.GUERREIRO;
                    break;
                    case 3:
                    classeEscolhida = Classe.ARQUEIRO;
                    break;
                    default:
                        classeEscolhida = Classe.MAGO;
        }

        Personagem jogador = new Personagem(nome, classeEscolhida);

        System.out.println("Escolha seu mascote:");

        if (classeEscolhida == Classe.MAGO) {
            System.out.println("1 - FADA");
            System.out.println("2 - CORUJA");

            int escolha = sc.nextInt();

            if (escolha == 1) jogador.escolherMascote(Mascote.FADA);
            else jogador.escolherMascote(Mascote.CORUJA);

        } else if (classeEscolhida == Classe.GUERREIRO) {
            System.out.println("1 - LOBO");
            System.out.println("2 - DRAGAO");

            int escolha = sc.nextInt();

            if (escolha == 1) jogador.escolherMascote(Mascote.LOBO);
            else jogador.escolherMascote(Mascote.DRAGAO);

        } else {
            System.out.println("1 - CORUJA");
            System.out.println("2 - LOBO");

            int escolha = sc.nextInt();

            if (escolha == 1) jogador.escolherMascote(Mascote.CORUJA);
            else jogador.escolherMascote(Mascote.LOBO);
        }

        Random random = new Random();
        Classe[] classes = Classe.values();
        Classe classeInimiga = classes[random.nextInt(classes.length)];

        Personagem inimigo = new Personagem("Inimigo", classeInimiga);
        inimigo.escolherMascote(Mascote.LOBO);

        while (jogador.estaVivo() && inimigo.estaVivo()) {
            System.out.println("\nSua vez");
            System.out.println("1 - Atacar");
            System.out.println("2 - Defender");

            int acao = sc.nextInt();

            if (acao == 1) {
                jogador.atacar(inimigo);
            } else {
                jogador.defender();
            }
            if (inimigo.estaVivo()) {
                System.out.println("\nTurno do Inimigo...");
                int escolhaInimigo = random.nextInt(2);
                if (escolhaInimigo == 0) {
                    inimigo.atacar(jogador);
                } else {
                    inimigo.defender();
                }
            }
            jogador.mostrarStatus();
            inimigo.mostrarStatus();
        }

        if (jogador.estaVivo()) {
            System.out.println("Voce venceu");
        } else {
            System.out.println("Voce perdeu");
        }
    }
}
