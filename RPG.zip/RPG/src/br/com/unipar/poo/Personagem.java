package br.com.unipar.poo;

import java.lang.classfile.ClassFile;

public class Personagem {
    private String nome;
    private int vida;
    private int forca;
    private int defesa;
    private int nivel;

    private Classe classe;
    private Mascote mascote;

    private boolean defendendo;

    public Personagem(String nome, Classe classe) {
        this.nome = nome;
        this.classe = classe;

        this.nivel = 1;

        this.vida = 100;
        this.forca = 20;
        this.defesa = 10;
    }

    public String getNome() {
        return nome;
    }

    public int getVida() {
        return vida;
    }

    public Classe getClasse() {
        return classe;
    }

    public Mascote getMascote() {
        return mascote;
    }

    public void escolherMascote(Mascote mascote) {
        if (classe == Classe.MAGO) {
            if (mascote == Mascote.FADA || mascote == Mascote.CORUJA) {
                this.mascote = mascote;
                System.out.println(nome+" escolheu o mascote "+mascote);
            } else {
                System.out.println("Mascote invalido para MAGO");
            }
        } else if (classe == Classe.GUERREIRO) {
            if (mascote == Mascote.LOBO || mascote == Mascote.DRAGAO) {
                this.mascote = mascote;
                System.out.println(nome+" escolheu o mascote "+mascote);
            } else {
                System.out.println("Mascote invalido para GUERREIRO");
            }
        } else if (classe == Classe.ARQUEIRO) {
            if (mascote == Mascote.CORUJA || mascote == Mascote.LOBO) {
                this.mascote = mascote;
                System.out.println(nome+" escolheu o mascote "+mascote);
            } else {
                System.out.println("Mascote invalido para ARQUEIRO");
            }
        }
    }

    public void atacar(Personagem inimigo) {
        int danoBase = this.forca - inimigo.defesa;
        if (danoBase < 0) {
            danoBase = 0;
        }
        System.out.println(this.nome + " atacou " + inimigo.nome + "!");
        System.out.println("Dano causado: "+danoBase);
        inimigo.receberDano(danoBase);
    }

    public void receberDano(int dano) {
        if (defendendo) {
            dano = dano /2;
            System.out.println(nome+" reduziu o dano pela metate");
            defendendo = false;
        }
        this.vida -= dano;
        if(this.vida < 0) {
            this.vida = 0;
        }
        System.out.println(nome+" agora tem "+vida+" de vida");
    }

    public boolean estaVivo() {
        return vida>0;
    }

    public void mostrarStatus() {
        System.out.println("====== STATUS ======");
        System.out.println("Nome: "+nome);
        System.out.println("Classe: "+classe);
        System.out.println("Vida: "+vida);
        System.out.println("Mascote: "+mascote);
        System.out.println("====================");
    }

    public void defender() {
        defendendo = true;
        System.out.println(nome+" esta se defendendo");
    }



}
