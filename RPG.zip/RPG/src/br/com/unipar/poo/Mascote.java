package br.com.unipar.poo;

public enum Mascote {
    FADA,
    CORUJA,
    LOBO,
    DRAGAO
}
